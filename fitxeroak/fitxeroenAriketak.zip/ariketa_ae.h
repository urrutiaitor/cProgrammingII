#ifndef ARIKETAAE_H

#define ARIKETAAE_H

#include <stdio.h>
#include <Windows.h>

#define MAX_IZENA 30
#define BAI 1
#define EZ 0
#define UBIKAZIOA_MAX 150
#define FITXERO_MAX 30

int main();
void ubikazioaLortu(char ubikazioa[UBIKAZIOA_MAX]);
int tamainaMaximoaLortu(int tamaina);
void zatienBanaketaEgin(int tamaina, char ubikazioa[UBIKAZIOA_MAX]);
void hasieraTextua();


#endif