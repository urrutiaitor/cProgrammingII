#ifndef DATUENMODIFIKAZIOA_H
#define DATUENMODIFIKAZIOA


void DATUENMODIFIKAZIOA_notakModifikatu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_notakSartu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_ikasleBatSartu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_eskolakoDatuakSartu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_eskolakoDatuakModifikatu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_ikasleakGeletanBanatu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_gelaFisikoaAsignatu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_irakasleakAsignatu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_tutoreaAsignatu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_batenDatuakSartu(ESKOLA eskolak[ESKOLAMAX],int gela);
void DATUENMODIFIKAZIOA_ikaslearenIkasgaiakSartu(ESKOLA eskolak[ESKOLAMAX],int gela);
void DATUENMODIFIKAZIOA_ikasgaiakSartu(ESKOLA eskolak[ESKOLAMAX],int gela);
void DATUENMODIFIKAZIOA_ikasgaiakSartuAdministrazioa(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_eskolakoIzenaModifikatu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_eskolakoHelbideaModifikatu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_eskolakoTelefonoaModifikatu(ESKOLA eskolak[ESKOLAMAX]);
void DATUENMODIFIKAZIOA_eskolakoMailakJarri(ESKOLA eskolak[ESKOLAMAX]);

#endif