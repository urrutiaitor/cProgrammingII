#ifndef MENUA_H
#define MENUA

int MENUA_erabiltzaileaAukeratu(ESKOLA eskolak[ESKOLAMAX]);

void MENUA_eskolaAukeratuAdministratzailea(ESKOLA eskolak[ESKOLAMAX]);

void MENUA_aukerakAdministratzailea(ESKOLA eskolak[ESKOLAMAX]);

void MENUA_aukerakIrakaslea(ESKOLA eskolak[ESKOLAMAX]);

void MENUA_aukerakIkaslea(ESKOLA eskolak[ESKOLAMAX]);





int MENUA_erabiltzaileaAukeratuBistaratu(ESKOLA eskolak[ESKOLAMAX]);

int MENUA_aukerakAdministratzaileaBistaratu(ESKOLA eskolak[ESKOLAMAX]);

int MENUA_aukerakIrakasleaBistaratu(ESKOLA eskolak[ESKOLAMAX]);

int MENUA_aukerakIkasleaBistaratu(ESKOLA eskolak[ESKOLAMAX]);

void MENUA_eskolaAukeratuBistaratu(ESKOLA eskolak[ESKOLAMAX]);
#endif