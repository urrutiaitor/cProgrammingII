#ifndef BISTARATU_H
#define BISTARATU


int BISTARATU_gelaAukeratu(ESKOLA eskolak[ESKOLAMAX]);
void BISTARATU_notakBistaratuIkaslearentzat(ESKOLA eskolak[ESKOLAMAX]);
void BISTARATU_notakBistaratuIrakaslearentzat(ESKOLA eskolak[ESKOLAMAX]);
void BISTARATU_ikaslearenBatezbestekoa(ESKOLA eskolak[ESKOLAMAX]);
void BISTARATU_taldekoIkasgaikoBatezbestekoa(ESKOLA eskolak[ESKOLAMAX]);
void BISTARATU_taldekoBatezbestekoa(ESKOLA eskolak[ESKOLAMAX]);
void BISTARATU_taldekoBatezbestekoHoberena(ESKOLA eskolak[ESKOLAMAX]);
void BISTARATU_taldekoIkasleakBatezbestekoarenArabera(ESKOLA eskolak[ESKOLAMAX]);

#endif